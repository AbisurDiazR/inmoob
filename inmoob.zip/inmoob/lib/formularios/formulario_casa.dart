import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:multi_image_picker/multi_image_picker.dart';

class AgregarCasa extends StatefulWidget {
  State createState() => AgregarCasaState();
}

class AgregarCasaState extends State<AgregarCasa> {
  String _selectedText = 'Venta';
  List<Asset> image = List<Asset>();
  String _error = 'No error detected';

  Future<void> loadAssets() async{
    setState(() {
      image = List<Asset>();
    });

    List<Asset> resultList = List<Asset>();
    String error = 'No error detected';

    try {
      resultList = await MultiImagePicker.pickImages(
        maxImages: 300,
        enableCamera: true,
        cupertinoOptions: CupertinoOptions(takePhotoIcon: "chat"),
        materialOptions: MaterialOptions(
          actionBarColor: "#abcdef",
          actionBarTitle: 'Selector de fotos',
          allViewTitle: 'Todas las fotos',
          useDetailsView: false,
          selectCircleStrokeColor: "#000000"
        ),
      );
    } on PlatformException catch (e) {
      error = e.message;
    }
    if (!mounted) return;

    setState(() {
      image = resultList;
      _error = error;
    });
  }

  Item selectedUser;
  List<Item> users = <Item>[
    const Item(
        'Android',
        Icon(
          Icons.android,
          color: const Color(0xFF167F67),
        )),
    const Item(
        'Flutter',
        Icon(
          Icons.flag,
          color: const Color(0xFF167F67),
        )),
    const Item(
        'ReactNative',
        Icon(
          Icons.format_indent_decrease,
          color: const Color(0xFF167F67),
        )),
    const Item(
        'iOS',
        Icon(
          Icons.mobile_screen_share,
          color: const Color(0xFF167F67),
        )),
  ];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Inmoob'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          children: <Widget>[
            //Ubicación del inmueble
            TextFormField(
              decoration: InputDecoration(
                  icon: Icon(Icons.location_on),
                  hintText: 'Ubicación del inmueble',
                  labelText: 'Ubicación'),
            ),

            //Precio del inmueble
            TextFormField(
              decoration: InputDecoration(
                icon: Icon(Icons.monetization_on),
                hintText: 'Precio del inmueble',
                labelText: 'Precio',
              ),
              keyboardType: TextInputType.number,
            ),

            //Monedas inmueble
            DropdownButton(
              hint: Text('Seleccione moneda'),
              value: selectedUser,
              onChanged: (Item value) {
                setState(() {
                  selectedUser = value;
                });
              },
              items: users.map((Item user) {
                return DropdownMenuItem<Item>(
                  value: user,
                  child: Row(
                    children: <Widget>[
                      user.icon,
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        user.name,
                        style: TextStyle(color: Colors.black),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),

            //Superficie total
            TextFormField(
              decoration: InputDecoration(
                  icon: Icon(Icons.location_searching),
                  hintText: 'Superficie total',
                  labelText: 'Superficie total'),
              keyboardType: TextInputType.number,
            ),

            //Superficie cubierta
            TextFormField(
              decoration: InputDecoration(
                  icon: Icon(Icons.location_searching),
                  hintText: 'Superficie cubierta',
                  labelText: 'Superficie cubierta'),
              keyboardType: TextInputType.number,
            ),

            //Numero de cuartos
            TextFormField(
              decoration: InputDecoration(
                  icon: Icon(Icons.room_service),
                  hintText: 'Numero de cuartos',
                  labelText: 'Cuartos'),
              keyboardType: TextInputType.number,
            ),

            //Numero de baños
            TextFormField(
              decoration: InputDecoration(
                  icon: Icon(Icons.clear_all),
                  hintText: 'Numero de baños',
                  labelText: 'Baños'),
              keyboardType: TextInputType.number,
            ),

            //Operaciones
            DropdownButton(
              hint: Text('Tipo de operación'),
              value: _selectedText,
              items: <String>['Venta', 'Renta'].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (String val) {
                _selectedText = val;
                setState(() {
                  //Esta funcion nos puede servir para el tipo operacion
                  _selectedText = val;
                  print(val);
                });
              },
            ),

            //Descripcion opcional
            TextFormField(
              decoration: InputDecoration(
                  icon: Icon(Icons.text_fields),
                  hintText: 'Descripción opcional',
                  labelText: 'Descripción opcional'),
              maxLines: null,
              keyboardType: TextInputType.multiline,
            ),

            //Boton para añadir fotos
            Center(
              child: FlatButton.icon(
                  onPressed: () {
                    loadAssets();
                  },
                  icon: Icon(Icons.add_a_photo),
                  label: Text('Añadir fotos'),
                  color: Colors
                      .blue, //specify background color for the button here
                  colorBrightness: Brightness
                      .dark, //specify the color brightness here, either `Brightness.dark` for darl and `Brightness.light` for light
                  disabledColor: Colors
                      .blueGrey, // specify color when the button is disabled
                  highlightColor: Colors
                      .red, //color when the button is being actively pressed, quickly fills the button and fades out after
                  padding:
                      EdgeInsets.symmetric(horizontal: 8.0, vertical: 5.0)),
            ),

            //Aqui va un list para las fotos
            Center(
              child: Container(
                padding: EdgeInsets.all(10.0),
                child: Text('Error: $_error', style: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontStyle: FontStyle.italic
                ),),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(5.0)),
                  border: Border.all(color: Color(0xFF000000))
                ),
              ),
            ),
            Expanded(
              child: buildGridView(),
            ),

            //Boton para añadir casa
            Center(
              child: FlatButton.icon(
                onPressed: () {
                  print('Añadir fotos');
                },
                icon: Icon(Icons.add),
                label: Text('Añadir inmueble'),
                color: Colors.red,
                colorBrightness: Brightness.dark,
                disabledColor: Colors.redAccent,
                highlightColor: Colors.green,
                padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 5.0),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget buildGridView(){
    return GridView.count(
      crossAxisCount: 3,
      children: List.generate(image.length, (index){
        Asset asset = image[index];
        return AssetThumb(
          asset: asset,
          height: 300,
          width: 300,
        );
      }),
    );
  }
}

class Item {
  const Item(this.name, this.icon);
  final String name;
  final Icon icon;
}
